from pyexcel_xls import read_data
from bs4 import BeautifulSoup
import urllib.request
import re
import xlsxwriter
import sqlite3

#########^^^^^^^^^^^^^^^^^^^SCENARIO 1(Fetching URL and storing output in spreadsheet)^^^^^^^^^^^^^^^^^^^^###########
# ************Reading Data From Excel**************

sample=read_data("/Users/Heba/Desktop/sample.xlsx")

url1=sample["beas_kund_trek"][0][0]
words_bKTrek=[]
for x in range(1,8):
    words_bKTrek.append(sample["beas_kund_trek"][x][0])

url2=sample["tsomoriri_trek"][0][0]
words_tTrek=[]
for x in range(1,5):
    words_tTrek.append(sample["tsomoriri_trek"][x][0])


url3=sample["food_blog"][0][0]
words_foodBlog=[]
for x in range(1,6):
    words_foodBlog.append(sample["food_blog"][x][0])

# ***************Class created for fetching text from the URL *****************

class Counting:
    "Class for web scrapping"
    def __init__(self, url=""):
        self.url=url

    def gettingText(self):
        "Function for getting content of url"
        self.req=urllib.request.Request(self.url,data=None,headers={'User-Agent':'Mozilla/5.0 (Macintosh;Intel Mac OS X 10_9_3)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36'})
        self.f=urllib.request.urlopen(self.req)
        self.soup =BeautifulSoup(self.f,'html.parser')
        self.texts=self.soup.findAll(text=True)
        return self.texts

    def visible(self,element):
        "Function for getting text from the content"
        if element.parent.name in ['style','script','[document]','head','title']:
            return False
        elif re.match('<!--.*-->',str(element)):
            return False
        return True


    def countword(self,word):
        "Function for counting word occured in the text"
        texts=self.gettingText()
        visible_texts=list(filter(self.visible,texts))
        wordcount=[]
        for line in visible_texts:
                if(line.count(word)!=0):
                    wordcount.append(line.count(word))
        totalcount=0
        for each in wordcount:
            totalcount+=each
        return word,totalcount

# *******End of Class********


# ***********Creating Class Object for 1st URL***********

c1=Counting(url1)
count1=dict(map(c1.countword,words_bKTrek))

# *****Creating Dictionary for storing Word, count and frequency *********
totalFreq=0
for eachFreq in count1.values():
    totalFreq+=eachFreq
freq1={x:{'count':count1.get(x),
          'frequency': count1.get(x)/totalFreq*100} for x in count1.keys()}


# ***********Creating Class Object for 2nd URL***********

c2=Counting(url2)
count2=dict(map(c2.countword,words_tTrek))

# *****Creating Dictionary for storing Word, count and frequency *********

totalFreq=0
for eachFreq in count2.values():
    totalFreq+=eachFreq
freq2={x:{'count':count2.get(x),
          'frequency': count2.get(x)/totalFreq*100} for x in count2.keys()}

# ***********Creating Class Object for 3rd URL***********

c3=Counting(url3)
count3=dict(map(c3.countword,words_foodBlog))

# *****Creating Dictionary for storing Word, count and frequency *********

totalFreq=0
for eachFreq in count3.values():
    totalFreq+=eachFreq
freq3={x:{'count':count3.get(x),
          'frequency': count3.get(x)/totalFreq*100} for x in count3.keys()}



# ******* Creating Output Spreadsheet containing 3 sheets*************

workbook=xlsxwriter.Workbook("/Users/Heba/Desktop/output.xlsx")
heading_format=workbook.add_format({'bold': True,'italic': True,'text_wrap':'True','font_color':'red','font_name':'Calibri','font_size':16,'align':'center'})
content_format=workbook.add_format({'font_color':'green','font_name':'Calibri','font_size':14,'align':'justify'})

worksheet1= workbook.add_worksheet("beas_kund_trek")
worksheet2= workbook.add_worksheet("tsomoriri_trek")
worksheet3= workbook.add_worksheet("food_blog")

# ****** Function for writing word, frequency and count in Output Excel ***************

def output(worksheet,url,freq):
    worksheet.write("A1",url,heading_format)
    worksheet.write("A2","Words",heading_format)
    worksheet.write("B2","Count",heading_format)
    worksheet.write("C2","Frequency",heading_format)


    count=2
    for each in freq.keys():
        worksheet.write(count,0,each,content_format)
        worksheet.write(count,1,freq[each]['count'],content_format)
        worksheet.write(count,2,freq[each]['frequency'],content_format)
        count+=1

 
#***** Calling output function to write in Output spreadsheet in beas_kund_trek sheet and Creating Pie Chart***************
output(worksheet1,url1,freq1)
chart1=workbook.add_chart({'type':'pie'})
chart1.add_series({'name':'Beas Kund SEO',
    'categories': '=beas_kund_trek!$A3:$A9',
    'values':'=beas_kund_trek!$C3:$C9',
    'data_labels':{'value':True}
                  })
chart1.set_title({'name':'Beas Kund SEO',})
chart1.set_style(10)
worksheet1.insert_chart("D6",chart1, {'x_offset': 25, 'y_offset': 10})


#***** Calling function to write in Output spreadsheet in tsomoriri_trek sheet and Creating Column Chart***************

output(worksheet2,url2,freq2)
chart2=workbook.add_chart({'type':'column'})
chart2.add_series({
        'categories': '=tsomoriri_trek!$A3:$A6',
            'name':   '=tsomoriri_trek!$B$2',
       'values': '=tsomoriri_trek!$B3:$B6',
        'data_labels':{'value':True},
    'pattern': {
        'pattern':  'shingle',
        'fg_color': '#804000',
        'bg_color': '#c68c53'
    },
    'border':  {'color': '#804000'},
    'gap':     70,
})

chart2.add_series({
                'name':   '=tsomoriri_trek!$C$2',
    'values': '=tsomoriri_trek!$C3:$C6',
     'data_labels':{'value':True},
    'pattern': {
        'pattern':  'horizontal_brick',
        'fg_color': '#b30000',
        'bg_color': '#ff6666'
    },
    'border':  {'color': '#b30000'},
})

chart2.set_title ({'name': 'Tsomoriri Trek SEO'})
chart2.set_x_axis({'name': 'SEO Words'})
chart2.set_y_axis({'name': 'Count and Frequency'})
worksheet2.insert_chart('D6', chart2)

#***** Calling function to write in Output spreadsheet in food_blog sheet and Creating Gradient Column Chart***************

output(worksheet3,url3,freq3)
chart3=workbook.add_chart({'type':'column'})
chart3.add_series({
    'name':       'food_blog!$B$2',
    'categories': '=food_blog!$A$3:$A$7',
    'values':     '=food_blog!$B$3:$B$7',
    'data_labels':{'value':True},
    'gradient':   {'colors': ['#963735', '#F1DCDB']}
})
chart3.add_series({
    'name':       '=food_blog!$C$2',
    'categories': '=food_blog!$A$3:$A$7',
    'values':     '=food_blog!$C$3:$C$7',
    'data_labels':{'value':True},
    'gradient':   {'colors': ['#E36C0A', '#FCEADA']}
})
chart3.set_plotarea({
    'gradient': {'colors': ['#FFEFD1', '#F0EBD5', '#B69F66']}
})
chart3.set_title ({'name': 'Food Blog SEO'})
chart3.set_x_axis({'name': 'SEO Words'})
chart3.set_y_axis({'name': 'Count And Frequency'})
worksheet3.insert_chart('E6', chart3)



workbook.close()

#########^^^^^^^^^^^^^^^^^^^SCENARIO 2(Fetching URL and storing output using SQLITE3 Database)^^^^^^^^^^^^^^^^^^^^###########

# ****************Fetching URL from SQLITE3******************* 
flag=0
while(flag==0):
    try:
        flag=1
        # Creating Database - mydb.db
        conn=sqlite3.connect('mydb.db')

        #Creating Table for storing URL and words
        conn.execute("""CREATE TABLE SAMPLE
            (URL TEXT NOT NULL,
             WORD1 TEXT NOT NULL,
             WORD2 TEXT NOT NULL,
             WORD3 TEXT NOT NULL,
             WORD4 TEXT NOT NULL);""")
        #Inserting data in SAMPLE table 
        conn.execute("""INSERT INTO SAMPLE
                (URL,WORD1,WORD2,WORD3,WORD4)
                VALUES("http://www.tecmint.com/best-free-open-source-tools-2016/","best","free","open","software")""")


        dbURL="https://www.labnol.org/internet/facebook-image-recognition/29222/"
        dbword1="facebook"
        dbword2="photograph"
        dbword3="photo"
        dbword4="image"
        conn.execute("""INSERT INTO SAMPLE
                (URL,WORD1,WORD2,WORD3,WORD4)
                VALUES(?,?,?,?,?)""",(dbURL,dbword1,dbword2,dbword3,dbword4))

        # Creating Table for output
        conn.execute("""CREATE TABLE OUTPUT1
            (WORD TEXT NOT NULL,
             COUNT INT NOT NULL,
             FREQUENCY FLOAT NOT NULL);""")

        conn.execute("""CREATE TABLE OUTPUT2
            (WORD TEXT NOT NULL,
             COUNT INT NOT NULL,
             FREQUENCY FLOAT NOT NULL);""")

    except sqlite3.OperationalError:
        conn.execute("DROP TABLE IF EXISTS SAMPLE")
        conn.execute("DROP TABLE IF EXISTS OUTPUT1")
        conn.execute("DROP TABLE IF EXISTS OUTPUT2")
        flag=0

# ******* Fetching content from URL and then cleaning it and storing the Word, Count and Frequency in Dictionary************
cursor=conn.execute("SELECT * FROM SAMPLE")
count=0
for eachrow in cursor:
    fetchedWord=[]
    count+=1
    fetchedurl=eachrow[0]
    fetchedWord.extend([eachrow[1],eachrow[2],eachrow[3],eachrow[4]])
    dbc=Counting(fetchedurl)
    dbcount=dict(map(dbc.countword,fetchedWord))
    totalFreq=0
    for eachFreq in dbcount.values():
        totalFreq+=eachFreq
    dbfreq={}
    dbfreq={x:{'count':dbcount.get(x),
          'frequency': dbcount.get(x)/totalFreq*100} for x in dbcount.keys()}
    if count==1:
        for eachdbfreq in dbfreq.keys():
            conn.execute("""INSERT INTO OUTPUT1
                        (WORD,COUNT,FREQUENCY)
                        VALUES(?,?,?)""",(eachdbfreq,dbfreq[eachdbfreq]['count'],dbfreq[eachdbfreq]['frequency']))
    if count==2:
        for eachdbfreq in dbfreq.keys():
            conn.execute("""INSERT INTO OUTPUT2
                        (WORD,COUNT,FREQUENCY)
                        VALUES(?,?,?)""",(eachdbfreq,dbfreq[eachdbfreq]['count'],dbfreq[eachdbfreq]['frequency']))


#*************Printing Output from SQLITE3 Table*************
cursorOut1=conn.execute("SELECT * FROM OUTPUT1")
print("For 1st URL , Word, Count and Frequency from SQLITE3 Table")
for eachrow in cursorOut1:
    print(eachrow)

cursorOut2=conn.execute("SELECT * FROM OUTPUT2")
print("For 2nd URL , Word, Count and Frequency from SQLITE3 Table")
for eachrow in cursorOut2:
    print(eachrow)
    
conn.commit()
